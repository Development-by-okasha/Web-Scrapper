const express = require("express");
const axios = require("axios");
const cheerio = require("cheerio");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

const cleanText = (text) => {
  return text.replace(/\s+/g, " ").trim();
};

// Helper function to extract metadata
const getMetadata = ($) => {
  const metadata = {};
  $("meta").each((i, element) => {
    const name = $(element).attr("name") || $(element).attr("property");
    const content = $(element).attr("content");
    if (name && content) {
      metadata[name] = content;
    }
  });
  return metadata;
};

// Helper function to extract images
const getImages = ($) => {
  const images = [];
  $("img").each((i, element) => {
    const src = $(element).attr("src");
    const alt = $(element).attr("alt");
    if (src) {
      images.push({
        src: src,
        alt: alt || "",
      });
    }
  });
  return images;
};

// Helper function to extract links
const getLinks = ($) => {
  const links = [];
  $("a").each((i, element) => {
    const href = $(element).attr("href");
    const text = $(element).text().trim();
    if (href && !href.startsWith("#")) {
      links.push({
        url: href,
        text: text,
      });
    }
  });
  return links;
};

// Helper function to extract social media links
const getSocialMedia = ($) => {
  const socialPatterns = {
    facebook: /facebook\.com/i,
    twitter: /twitter\.com/i,
    linkedin: /linkedin\.com/i,
    instagram: /instagram\.com/i,
    youtube: /youtube\.com/i,
  };

  const socialLinks = {};
  $("a").each((i, element) => {
    const href = $(element).attr("href");
    if (href) {
      for (const [platform, pattern] of Object.entries(socialPatterns)) {
        if (pattern.test(href)) {
          socialLinks[platform] = href;
        }
      }
    }
  });
  return socialLinks;
};

app.post("/scrape", async (req, res) => {
  const url = req.body.link;

  if (!url) {
    return res.status(400).json({ error: "No URL provided" });
  }

  try {
    // Set custom headers to mimic a browser
    const headers = {
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      Accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.5",
    };

    const { data } = await axios.get(url, { headers });
    const $ = cheerio.load(data);

    // Extract comprehensive website data
    const websiteData = {
      url: url,
      metadata: getMetadata($),
      title: $("title").text().trim(),
      description: $('meta[name="description"]').attr("content"),

      // Main content
      headings: {
        h1: $("h1")
          .map((i, el) => cleanText($(el).text()))
          .get(),
        h2: $("h2")
          .map((i, el) => cleanText($(el).text()))
          .get(),
        h3: $("h3")
          .map((i, el) => cleanText($(el).text()))
          .get(),
      },

      paragraphs: $("p")
        .map((i, el) => cleanText($(el).text()))
        .get(),

      lists: {
        unordered: $("ul")
          .map((i, el) => ({
            items: $(el)
              .find("li")
              .map((i, li) => cleanText($(li).text()))
              .get(),
          }))
          .get(),
        ordered: $("ol")
          .map((i, el) => ({
            items: $(el)
              .find("li")
              .map((i, li) => cleanText($(li).text()))
              .get(),
          }))
          .get(),
      },

      // Media content
      images: getImages($),
      videos: $('video, iframe[src*="youtube"], iframe[src*="vimeo"]')
        .map((i, el) => ({
          src: $(el).attr("src"),
          type: $(el).prop("tagName").toLowerCase(),
        }))
        .get(),

      // Navigation and links
      links: getLinks($),
      navigation: $("nav, header")
        .find("a")
        .map((i, el) => ({
          text: cleanText($(el).text()),
          url: $(el).attr("href"),
        }))
        .get(),

      // Contact information
      contact: {
        emails:
          $("body")
            .html()
            .match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [],
        phones:
          $("body")
            .html()
            .match(/(\+\d{1,3}[-.]?)?\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}/g) || [],
        addresses: $("address")
          .map((i, el) => cleanText($(el).text()))
          .get(),
      },

      // Social media
      socialMedia: getSocialMedia($),

      // Forms
      forms: $("form")
        .map((i, el) => ({
          action: $(el).attr("action"),
          method: $(el).attr("method"),
          inputs: $(el)
            .find("input")
            .map((i, input) => ({
              type: $(input).attr("type"),
              name: $(input).attr("name"),
              placeholder: $(input).attr("placeholder"),
            }))
            .get(),
        }))
        .get(),

      // Structure data
      structuredData: $('script[type="application/ld+json"]')
        .map((i, el) => {
          try {
            return JSON.parse($(el).html());
          } catch (e) {
            return null;
          }
        })
        .get()
        .filter((item) => item !== null),
    };

    res.json({
      message: "Data scraped successfully",
      data: websiteData,
    });
  } catch (error) {
    console.error(`Error fetching data: ${error}`);
    res.status(500).json({
      error: "Error fetching data",
      details: error.message,
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: "Internal server error",
    details: err.message,
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
